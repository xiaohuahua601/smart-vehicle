<template>
  <h1>这个是字典选项管理</h1>
</template>

<script setup>
</script>

<style scoped>

</style>