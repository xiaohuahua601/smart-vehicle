<template>
  <h1>这个是围栏管理页管理</h1>
</template>

<script setup>
</script>

<style scoped>

</style>